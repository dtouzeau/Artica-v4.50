# enter perl script statements for any routes you might wish to add
# for example
# $B->add_route('192.168.100.1/32'=>'eth0');

