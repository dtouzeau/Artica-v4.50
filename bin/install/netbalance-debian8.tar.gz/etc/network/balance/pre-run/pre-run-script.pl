#!/bin/sh

# The contents of this directory will be run before any other commands
# are issued by load_balance.pl
