//Enable this option if you want use syslog daemon for logging
#define USE_SYSLOG
//Default directory for dump mail from mail server
#define DEFAULT_DUMPMAILDIR "/tmp/savemail"
//Default full file name for LOCK file
#define DEFAULT_DUMPMAIL_LOCK "/var/run/maildump.pid"
//Version of this program 
#define VERSION "2009.02"
//PREFIX for SQLTable
#define SQLTABLE_PREFIX "mailarchive"
