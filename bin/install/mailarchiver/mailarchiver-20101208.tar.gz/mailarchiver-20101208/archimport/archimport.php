<?php

include ("ftpcfg.php");
include ("ftpfunc.php");
$flag_filearch_subdir=true;	//settings - do we need subdir in filearchive

//�������� - �������� �� ���� ����� "�����"
function fnc_comparedomain_to_our($procemail)
  {
  global $cfg;
  $lendomain=strlen(trim($cfg->ourdomain));
  if ($lendomain<=0)
    return false;

  $lastpart=substr($procemail,-$lendomain);
  if (strcasecmp($lastpart,$cfg->ourdomain)!=0)
    return false;

  return true;
  }          

function fnc_date_calc($this_date,$num_days)
  {
  $my_time = strtotime ($this_date); //converts date string to UNIX timestamp
  $my_time_conv = getdate($my_time);
  $timestamp = mktime(0,0,0,$my_time_conv["mon"],$my_time_conv["mday"]+$num_days, $my_time_conv["year"]);
  $return_date = date("Y-m-d",$timestamp);  //puts the UNIX timestamp back into string format
  return $return_date;//exit function and return string
  }//end of function


function my_parseemail($procemail)
  {
  preg_match('/[\\w\\.\\-+=*_]*@[\\w\\.\\-+=*_]*/', $procemail , $regs);
  return $regs[0];
  }

function my_parse_and_load_file($procfilename)
  {
  global $cfg;
  global $myhost;

  $email_address=""; $email_body="";
  $email_header="";
  $email_header_mailfrom="";
  $email_header_mailfrom_flag_internal="";
  $email_header_rcptto="";
  $email_header_rcptto_count=0;
  $email_header_rcptto_array=array();
  $email_size=0;
  $email_spamrating=0;
  $email_subject="";
  $email_messageid="";
  $flag_header=1;
  $handle = fopen($procfilename, "r");
  while (!feof($handle)) 
    {
    $buffer = convert_cyr_string(fgets($handle, 4096), "a", "w");
    if ($flag_header==1)
      {
      if (strcasecmp("X-REAL-MAILFROM:",substr($buffer,0,16))==0)
        {
        $email_header_mailfrom=my_parseemail(substr($buffer,17));
        if (fnc_comparedomain_to_our($email_header_mailfrom)===false)
          $thisour=0;
        else
          $thisour=1;
        $email_header_mailfrom_flag_internal=$thisour;
        }
      if (strcasecmp("X-REAL-RCPTTO:",substr($buffer,0,14))==0)
        {
        $email_header_rcptto_count++;
        $email_header_rcptto.=",".my_parseemail(substr($buffer,15));
        $email_header_rcptto_array[]=my_parseemail(substr($buffer,15));
        }
      if (strcasecmp("X-Spam-Level:",substr($buffer,0,13))==0)
        $email_spamrating=strlen(trim(substr($buffer,13)));
      if (strcasecmp("Message-ID:",substr($buffer,0,11))==0)
        {
        $email_messageid=trim(substr($buffer,11));
        if (strlen($email_messageid)>0)
          {
          if (strcmp(substr($email_messageid,0,1),"<")==0)
            {
            $email_messageid=substr($email_messageid,1);
            $email_messageid=substr($email_messageid,0,-1);
            }
          }
        }
      if (strcasecmp("Subject:", substr($buffer, 0, 8))==0)
        $email_subject=trim(substr($buffer, 9));
      if (strlen($buffer)<=2)
        //��������� ����������. (������ ������) ������ ��� ���������� ����...
        $flag_header=0;
      else
        $email_header.=$buffer;
      }
    else
      $email_body.=$buffer;
    }
  fclose($handle);
  $email_size=filesize($procfilename);
  if ($email_size==0)	//if size is equal 0 byte then it error, 
    return false;	//in this case exit with error
  $email_header_rcptto.=",";

  $email_body=base64_encode($email_body);   //encode to BASE64
  $insertbody1='';
  $insertbody2='';
  if      ($cfg->storemode==1)
    $insertbody1=$email_body;
  else if ($cfg->storemode==2)
    $insertbody2=$email_body;

  my_query('insert into mailarchive (timeload, filename, mailsize, msgsubject, mailfrom, rcptto, rcptto_count, spamrating, messageid, msghead, msgbody, msginfo_storage) values ( NOW(), \''.$procfilename.'\' , '.$email_size.',\''.addslashes($email_subject).'\' ,\''.addslashes($email_header_mailfrom).'\' , \''.addslashes($email_header_rcptto).'\' , \''.(int)$email_header_rcptto_count.'\', \''.(int)$email_spamrating.'\', \''.addslashes($email_messageid).'\', \''.addslashes($email_header).'\',\''.addslashes($insertbody1).'\', '.(int)$cfg->storemode.')' );
  $msg_id_added=mysql_insert_id();
//  echo "Added Record=".$msg_id_added;    //debug msg
  if ($cfg->storemode==2)	//����� ����������� � ��������� �������
    my_query('insert into mailarchive_msginfo (MailID, MsgBody) values ( \''.$msg_id_added.'\' , \''.addslashes($insertbody2).'\')' );
  //now add into database recipients
  while( $row=array_shift($email_header_rcptto_array) )
    {
    if (fnc_comparedomain_to_our($row)===false)
      $thisour=0;
    else
      $thisour=1;

    my_query('insert into mailarchive_recipient (MailID, RcptTo, Flag_Internal) values ( \''.(int)$msg_id_added.'\' , \''.addslashes($row).'\', \''.(int)$thisour.'\')' );
    }

  //STATISTICS SUBMODULE
  if ($cfg->enable_stats==1)
    {
    if ($email_spamrating>5)
      $flag_spam=1;
    else
      $flag_spam=0;

    //if your sendmail send every "rcpt-to" as separate mail then use this settings, 
    $total_mail=$email_header_rcptto_count;
    //else uncomment next line
    //$total_mail=1;
//    echo $total_mail;

    $total_spam=$total_mail*$flag_spam;
    $total_spam_rating=$email_spamrating*$flag_spam;

    my_query('INSERT INTO mailerstatus (hostname, daterecord, total_size, total_mails, total_spam, total_spam_rating) values(\''.$myhost.'\', NOW(), \''.(int)$email_size.'\',\''.(int)$total_mail.'\', \''.(int)$total_spam.'\', \''.(int)$total_spam_rating.'\')');
    }
//  if (unlink($procfilename)===FALSE)
//    die("Unlink file error");
  return true;
  }

//*********************************************************
//select and remove all records that we must remove from DB
//�������� � ������� ��� ������ ������� �� ������ ������� �� ��...
function fnc_removeoldinfo_preparelist($thisperiod, $thismailsize)
  {
  $retarray=Array();
  $limittext="LIMIT 10";
  $today_formatted=date("Y-m-d",time());
  $period_remove=fnc_date_calc($today_formatted,$thisperiod);
  $sqlquery="select idrecord, msginfo_storage from mailarchive WHERE TimeLoad<='".$period_remove."' and mailsize>'".(int)$thismailsize."' and (msgbody_removed=0 or msgbody_removed is null) order by idrecord ".$limittext;
  $res = my_query($sqlquery);
  if (mysql_num_rows($res))
    {
    while($row=mysql_fetch_array($res))
      $retarray[]=$row;
    }
  return $retarray;
  }

function fnc_removeoldinfo($thisperiod, $thismailsize)
  {
  $retinfo=fnc_removeoldinfo_preparelist($thisperiod, $thismailsize);
  if (count($retinfo)==0)
    return true;
  while( $row=array_shift($retinfo))
    {
    $myquery1='';
    $myquery2='';
    $myquery3='';
    if ($thismailsize>0)
      {
      if      ($row["msginfo_storage"]==1 || $row["msginfo_storage"]==0)
        $myquery1="UPDATE mailarchive set msgbody='', msgbody_removed=1 WHERE idrecord=".$row["idrecord"];
      else if ($row["msginfo_storage"]==2)
        {
        $myquery1="DELETE FROM mailarchive_msginfo WHERE mailid=".$row["idrecord"];
        $myquery2="UPDATE mailarchive set msgbody_removed=1 WHERE idrecord=".$row["idrecord"];
        }
      }
    else
      {
      $myquery1="DELETE FROM mailarchive_recipient WHERE mailid=".$row["idrecord"];
      $myquery2="DELETE FROM mailarchive_msginfo WHERE mailid=".$row["idrecord"];
      $myquery3="DELETE FROM mailarchive         WHERE idrecord=".$row["idrecord"];
      }
    my_query($myquery1);
    if (strlen($myquery2)>0)
      my_query($myquery2);
    if (strlen($myquery3)>0)
      my_query($myquery3);
    }
  return true;
  }

function fnc_makedirarchname_and_create($basename, $fullfilename)
  {
  global $flag_filearch_subdir;
  if ($flag_filearch_subdir==true)
    {
    $proc_formatted=$basename.'/'.date("Y/Y_m");
    if (file_exists($proc_formatted)===FALSE)
      if (!mkdir($proc_formatted,0,true))
        die("cannot create directory");
    }
  else
    $proc_formatted=$basename;
  return $proc_formatted;
  }
//*********************************************************

$dir           = '/tmp/savemail/';
$dir_archascii = '/var/spool/mailarch';
$myhost=trim(shell_exec('/bin/hostname'));
$files1 = scandir($dir);
if (is_dir($dir_archascii))
  $flag_filearch=true;
else
  $flag_filearch=false;
end;

my_connect();
//Set variables for very BIG disk C
//my_query("set SESSION max_allowed_packet = 64000000;");
ini_set('memory_limit', '256M');

while($currfile=array_shift($files1))
  if (is_file($dir.$currfile))
    {
    $extension = end(explode(".", $currfile));
    if ($extension=="msg")
      {
      $fullfilename=$dir.$currfile;
      if (my_parse_and_load_file($dir.$currfile))
        ;
      else
        die("ErrorLoading");
      //successfull load, now we need to move file to ascii archive or totally remove
      if ($flag_filearch==true)
        {
        if (rename($fullfilename, fnc_makedirarchname_and_create($dir_archascii, $fullfilename).'/'.$currfile)===FALSE)
          die("move file error");
        }
      else
        if (unlink($fullfilename)===FALSE)
          die("Unlink file error");
      }
    }

//now we clean database, we must remove too big or too old mail
//we work in Linux-HA cluster, and want to clean database only from one host...
if (strcasecmp($myhost,"ajax-cluster-2.eab.ru")==0)
  {
  fnc_removeoldinfo(-365,      0);	//first we clean too old messages
  fnc_removeoldinfo( -60,1024000);	//����� ������ 1��
  fnc_removeoldinfo( -90, 512000);	//����� ������ 512K
  fnc_removeoldinfo(-120, 256000);       //�����        256K
  fnc_removeoldinfo(-180, 128000);       //�            128K
//  my_query("OPTIMIZE TABLE `mailarchive` ");

  }

?>
