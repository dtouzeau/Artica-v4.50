<?
/*
 * Utility functions
 *
 * (C) Daniel Sundberg <sumpan@gmail.com> and Per Åkergren 2001-2005
 *
 * Connect to the database
 */
function my_connect(){
  global $cfg;
  $sql = mysql_connect($cfg->db_host,$cfg->db_user,$cfg->db_pass);
  if(!$sql) die("Cannot connect to database:" . mysql_error());

  $sql = mysql_select_db($cfg->db_name);
  if(!$sql) die("Cannot change db:" . mysql_error());
}

/*
 * Run a mysql-query
 */
function my_query($query){
  $sql = mysql_query($query);
  if(!$sql) die("Bad query: \"$query\": " . mysql_error()); 
  return $sql;  
}


?>