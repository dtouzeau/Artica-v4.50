<?
/*
 * Configuration data
 */

class dummy{};
$cfg = new dummy();

$cfg->db_host="192.168.0.116";
$cfg->db_name="eab_websys";
/*
 * User and passwd for readonly db-user
 */
$cfg->db_user="eab_websysuser";
$cfg->db_pass="42f.eUE6DL:PL9fj"; 
$cfg->storemode=2;		//1 - built-in store
				//2 - store body mail into separate table

$cfg->ourdomain='mymail.ru';	//name of our mail domain

//do we need create statistics record
$cfg->enable_stats=1;

?>

